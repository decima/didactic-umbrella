<div class="row">
    <div class="col-md-2">
        <img class="img-responsive" src="<?= $game["image"]; ?>"/>
    </div>
    <div class="col-md-10">
        <h1><?= $game["name"]; ?></h1>
    </div>
</div>
