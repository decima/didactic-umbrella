<div class="row">
    <h1><?= $player["username"]; ?>
        <small><?= $player["email"]; ?></small>
    </h1>
</div>
